from flask import Flask, render_template, request, redirect, url_for, jsonify
import mysql.connector
import re

app = Flask(__name__)

HOST_URL = "127.0.0.1"

# Connect to MySQL database
db = mysql.connector.connect(
    host=HOST_URL,
    user="root",
    password="@hmTech3005",
    database="user_info"
)

# Function to authenticate user
def authenticate_user(email, password):
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM `database` WHERE Email = %s AND Password = %s", (email, password))
    user = cursor.fetchone()
    cursor.close()
    return user

# Function to fetch students
def fetch_course_students(course_name):
    # Clean up the course name
    course_name = re.sub(r'[_-]', ' ', course_name)  # Replace "_" and "-" with space
    course_name = course_name.title()  # Capitalize the first letter of each word

    cursor = db.cursor(dictionary=True)
    query = "SELECT Student_Name, Absences FROM course_students WHERE Course_Name = %s"
    cursor.execute(query, (course_name,))
    students = cursor.fetchall()
    cursor.close()
    return students

@app.route('/')
def index():
    return render_template('login-page-yassine-and-nour.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Authenticate user
        user = authenticate_user(email, password)
        if user:
            if user['Role'] == 'Professor':
                return redirect(url_for('professor_dashboard'), code=302)
            else:
                first_name = user['Firstname']
                last_name = user['Lastname']
                full_name = f"{first_name} {last_name}"
                return redirect(url_for('student_dashboard', full_name=full_name), code=302)

        # If login fails, show error message
        error = 'Invalid email, password, or role. Please try again.'
        return render_template('login.html', error=error)

    # If method is GET, show login form
    return render_template('login.html')

@app.route('/professor_dashboard')
def professor_dashboard():
    return render_template('professor_dashboard.html')
    

@app.route('/<course_name>')
def course_details(course_name):
    # Clean up the course name
    course_name = re.sub(r'[_-]', ' ', course_name)  # Replace "_" and "-" with space
    course_name = course_name.title()  # Capitalize the first letter of each word

    cursor = db.cursor(dictionary=True)
    query = "SELECT Student_Name, Absences FROM course_students WHERE Course_Name = %s"
    cursor.execute(query, (course_name,))
    students = cursor.fetchall()
    cursor.close()

    return render_template('Course-details.html', course_name=course_name, students=students, save_url=url_for('save_absences'))

@app.route('/student_dashboard/<full_name>')
def student_dashboard(full_name):
    #Fetch the student's courses and absences
    cursor = db.cursor(dictionary=True)
    query = "SELECT Course_Name, Absences FROM course_students WHERE Student_Name = %s"
    cursor.execute(query, (full_name,))
    courses = cursor.fetchall()
    cursor.close()

    return render_template('student_dashboard.html', full_name=full_name, courses=courses)

ABSENCE_STATUS_DECREMENT = 'decrement'
ABSENCE_STATUS_ABSENT = 'Absent'

@app.route('/save_absences', methods=['POST'])
def save_absences():
    course_name = request.form['course_name']
    student_names = request.form.getlist('student_name[]')
    absences = [int(absence) for absence in request.form.getlist('absences[]')]
    presence_status = [presence.lower() == 'true' for presence in request.form.getlist('presence_status[]')]

    
    try:
        cursor = db.cursor()
        for i, student_name in enumerate(student_names):
            if presence_status[i] == False:
                if absences[i] == 0:
                    absences[i] = 0
                else:
                    absences[i] = absences[i] - 1
            query = "UPDATE course_students SET Absences = %s WHERE Student_Name = %s AND Course_Name = %s"
            cursor.execute(query, (absences[i], student_names[i], course_name))
        db.commit()

        # Return a success message
        return jsonify({'message': 'Absences saved successfully'})

    except Exception as e:
        print(f"Error: {e}")

    finally:
        cursor.close()



       

    

if __name__ == '__main__':
    app.run(debug=True)