from flask import Flask, render_template, request
import mysql.connector

app = Flask(__name__)

# Connect to MySQL database
conn = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="@hmTech3005",
    database="user_info"
)

# Create cursor
cursor = conn.cursor()

# Function to add user to database
def add_user(email, first_name, last_name, password):
    cursor.execute("INSERT INTO `database` (Email, Firstname, Lastname, Password) VALUES (%s, %s, %s, %s)", (email, first_name, last_name, password))
    conn.commit()

@app.route('/')
def index():
    return render_template('Ahmed-Eya-portal.html')

@app.route('/signup', methods=['POST'])
def signup():
    email = request.form['email']
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    password = request.form['password']
    confirm_password = request.form['confirm_password']
    
    # Simple validation
    if not email or not first_name or not last_name or not password or not confirm_password:
        return "Please fill out all fields"
    if password != confirm_password:
        return "Passwords do not match"
    
    # Add user to database
    try:
        add_user(email, first_name, last_name, password)
        return f"Signed up successfully with email: {email}, first name: {first_name}, last name: {last_name}"
    except mysql.connector.Error as e:
        return f"Error: {e}"

if __name__ == '__main__':
    app.run(debug=True)
